package com.ai.screentranslator

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.util.DisplayMetrics
import android.view.WindowManager

/**
 * فئة التقاط الشاشة الحقيقية (التي كانت مفقودة في الكود السابق)
 * تحل مشكلة Row-Stride و Padding Bytes الشائعة في معالجات
 * MediaTek Dimensity 7025 Ultra و Snapdragon في أجهزة شاومي
 */
class ScreenCaptureManager(
    private val context: Context,
    resultCode: Int,
    resultData: Intent
) {
    private val mediaProjectionManager =
        context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var screenWidth: Int = 1080
    private var screenHeight: Int = 2400
    private var screenDensity: Int = 400

    init {
        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)

        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        screenDensity = metrics.densityDpi

        // إنشاء كائن MediaProjection بأمان
        mediaProjection = mediaProjectionManager.getMediaProjection(resultCode, resultData)
        setupVirtualDisplay()
    }

    private fun setupVirtualDisplay() {
        // إنشاء ImageReader لتلقي إطارات الشاشة بصيغة RGBA_8888
        imageReader = ImageReader.newInstance(
            screenWidth,
            screenHeight,
            PixelFormat.RGBA_8888,
            2
        )

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "RedmiNote14ScreenCapture",
            screenWidth,
            screenHeight,
            screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            null
        )
    }

    /**
     * التقاط آخر إطار وتحويله إلى Bitmap مع مراعاة حشو الأسطر (Row Stride)
     */
    fun captureScreenBitmap(): Bitmap? {
        val reader = imageReader ?: return null
        var image: Image? = null
        try {
            image = reader.acquireLatestImage() ?: reader.acquireNextImage()
            if (image == null) return null

            val planes = image.planes
            val buffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val rowPadding = rowStride - pixelStride * screenWidth

            // معالجة مشكلة Stride: إذا كانت الشاشة تحتوي على Padding، نقوم باقتطاع العرض الفعلي
            val tempBitmap = Bitmap.createBitmap(
                screenWidth + rowPadding / pixelStride,
                screenHeight,
                Bitmap.Config.ARGB_8888
            )
            tempBitmap.copyPixelsFromBuffer(buffer)

            // إعادة Bitmap بالأبعاد الدقيقة لشاشة Redmi Note 14
            val croppedBitmap = Bitmap.createBitmap(tempBitmap, 0, 0, screenWidth, screenHeight)
            if (tempBitmap != croppedBitmap) {
                tempBitmap.recycle()
            }
            return croppedBitmap
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        } finally {
            image?.close()
        }
    }

    fun release() {
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        mediaProjection?.stop()
        mediaProjection = null
    }
}