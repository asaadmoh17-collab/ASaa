package com.ai.screentranslator

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/**
 * شاشة البداية وضبط أذونات هاتف ريدمي نوت 14 وواجهة HyperOS
 */
class MainActivity : AppCompatActivity() {

    private lateinit var mediaProjectionManager: MediaProjectionManager
    private lateinit var btnToggleService: Button
    private lateinit var tvStatus: TextView
    private lateinit var btnHyperOSFix: Button

    private var isServiceRunning = false

    // معالج نتيجة إذن تسجيل الشاشة (MediaProjection) المتوافق مع أندرويد 14
    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            TranslationService.start(this, result.resultCode, result.data!!)
            isServiceRunning = true
            updateUIState()
            Toast.makeText(this, "تم تشغيل مترجم الألعاب بنجاح!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "تم رفض إذن التقاط الشاشة", Toast.LENGTH_SHORT).show()
        }
    }

    // معالج إذن الظهور فوق التطبيقات
    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (Settings.canDrawOverlays(this)) {
            requestMediaProjection()
        } else {
            Toast.makeText(this, "يجب منح إذن الظهور فوق التطبيقات للزر العائم", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mediaProjectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        btnToggleService = findViewById(R.id.btn_toggle_service)
        tvStatus = findViewById(R.id.tv_service_status)
        btnHyperOSFix = findViewById(R.id.btn_hyperos_fix)

        btnToggleService.setOnClickListener {
            if (isServiceRunning) {
                stopTranslatorService()
            } else {
                startTranslatorFlow()
            }
        }

        // زر فتح إعدادات شاومي الحصرية (HyperOS Permissions)
        btnHyperOSFix.setOnClickListener {
            openXiaomiHyperOSSettings()
        }

        // فحص قيود البطارية
        checkBatteryOptimization()
    }

    private fun startTranslatorFlow() {
        // 1. التحقق من إذن الظهور فوق التطبيقات
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
            return
        }

        // 2. طلب إذن تسجيل الشاشة
        requestMediaProjection()
    }

    private fun requestMediaProjection() {
        val captureIntent = mediaProjectionManager.createScreenCaptureIntent()
        screenCaptureLauncher.launch(captureIntent)
    }

    private fun stopTranslatorService() {
        TranslationService.stop(this)
        isServiceRunning = false
        updateUIState()
        Toast.makeText(this, "تم إيقاف خدمة المترجم", Toast.LENGTH_SHORT).show()
    }

    private fun updateUIState() {
        if (isServiceRunning) {
            btnToggleService.text = "إيقاف المترجم العائم"
            tvStatus.text = "الحالة: المترجم نشط فوق الألعاب"
            tvStatus.setTextColor(getColor(android.R.color.holo_green_light))
        } else {
            btnToggleService.text = "تشغيل المترجم العائم"
            tvStatus.text = "الحالة: متوقف"
            tvStatus.setTextColor(getColor(android.R.color.darker_gray))
        }
    }

    /**
     * حل مشاكل Xiaomi HyperOS على Redmi Note 14:
     * فتح شاشة الأذونات المتقدمة لتفعيل "عرض النوافذ المنبثقة في الخلفية"
     */
    private fun openXiaomiHyperOSSettings() {
        try {
            // توجيه المستخدم مباشرة لصفحة أذونات تطبيق شاومي
            val intent = Intent("miui.intent.action.APP_PERM_EDITOR").apply {
                setClassName(
                    "com.miui.securitycenter",
                    "com.miui.permcenter.permissions.PermissionsEditorActivity"
                )
                putExtra("extra_pkgname", packageName)
            }
            startActivity(intent)
        } catch (e: Exception) {
            // fallback إلى صفحة تفاصيل التطبيق العادية إذا لم يتم التعرف على Intent شاومي
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", packageName, null)
            }
            startActivity(intent)
        }
        Toast.makeText(
            this,
            "مهم: تأكد من تفعيل 'النوافذ المنبثقة أثناء التشغيل في الخلفية' و 'التشغيل التلقائي'",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun checkBatteryOptimization() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!powerManager.isIgnoringBatteryOptimizations(packageName)) {
                // اقتراح إلغاء توفير البطارية لضمان عدم إغلاق HyperOS للخدمة أثناء اللعب
                try {
                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = Uri.parse("package:$packageName")
                    }
                    startActivity(intent)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }
}