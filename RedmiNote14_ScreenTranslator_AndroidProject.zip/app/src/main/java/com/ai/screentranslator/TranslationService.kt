package com.ai.screentranslator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.google.ai.client.generativeai.GenerativeModel
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * خدمة ترجمة الشاشة مخصصة لهاتف Redmi Note 14
 * تعالج قيود Android 14 (API 34) وواجهة Xiaomi HyperOS:
 * 1. بدء Foreground Service بنوع MediaProjection قبل التقاط الشاشة
 * 2. زر عائم قابل للتحريك في أي مكان لتجنب حجب أزرار الألعاب
 * 3. معالجة محاذاة البايتات (Row Stride) في شاشات AMOLED 1080x2400
 */
class TranslationService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var floatingView: View
    private lateinit var windowParams: WindowManager.LayoutParams
    
    private val serviceJob = Job()
    private val serviceScope = CoroutineScope(Dispatchers.Main + serviceJob)
    
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    
    // استخدام نموذج Gemini السريع للألعاب
    // ضع مفتاح الـ API الخاص بك هنا أو قم بتمريره من واجهة التطبيق
    private val generativeModel = GenerativeModel(
        modelName = "gemini-2.0-flash",
        apiKey = BuildConfig.GEMINI_API_KEY
    )

    private var screenCaptureManager: ScreenCaptureManager? = null

    companion object {
        const val CHANNEL_ID = "ScreenTranslatorChannel"
        const val NOTIFICATION_ID = 1001
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        
        fun start(context: Context, resultCode: Int, data: Intent) {
            val intent = Intent(context, TranslationService::class.java).apply {
                putExtra(EXTRA_RESULT_CODE, resultCode)
                putExtra(EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
        
        fun stop(context: Context) {
            context.stopService(Intent(context, TranslationService::class.java))
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        initFloatingWidget()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // [إصلاح حرج لـ Android 14 على Redmi Note 14]:
        // يجب استدعاء startForeground بنوع FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        val notification = createForegroundNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID, 
                notification, 
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        // استلام توكن MediaProjection الممرر من MainActivity
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val resultData = intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)

        if (resultCode != 0 && resultData != null) {
            screenCaptureManager = ScreenCaptureManager(this, resultCode, resultData)
        } else {
            Toast.makeText(this, "يرجى منح إذن التقاط الشاشة", Toast.LENGTH_LONG).show()
        }

        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "خدمة مترجم الشاشة الذكي",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "إشعار استمرار تشغيل الترجمة العائمة فوق الألعاب"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun createForegroundNotification(): Notification {
        val stopIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, stopIntent, 
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("مترجم الألعاب نشط - Redmi Note 14")
            .setContentText("المترجم العائم جاهز. اضغط على الأيقونة للترجمة الفورية.")
            .setSmallIcon(R.drawable.ic_translate)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    /**
     * إعداد الزر العائم مع دعم السحب في كامل الشاشة (120Hz Touch)
     */
    private fun initFloatingWidget() {
        floatingView = LayoutInflater.from(this).inflate(R.layout.layout_floating_widget, null)

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        windowParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or 
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 80
            y = 300
        }

        val btnTranslate = floatingView.findViewById<ImageView>(R.id.btn_floating_translate)
        val btnClose = floatingView.findViewById<ImageView>(R.id.btn_close_overlay)
        val tvResult = floatingView.findViewById<TextView>(R.id.tv_translation_result)
        val progressBar = floatingView.findViewById<ProgressBar>(R.id.pb_loading)

        // تفعيل السحب اللمسي للأيقونة
        btnTranslate.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var isClick = true

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = windowParams.x
                        initialY = windowParams.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        isClick = true
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - initialTouchX).toInt()
                        val dy = (event.rawY - initialTouchY).toInt()
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
                            isClick = false
                        }
                        windowParams.x = initialX + dx
                        windowParams.y = initialY + dy
                        windowManager.updateViewLayout(floatingView, windowParams)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (isClick) {
                            captureAndTranslateScreen()
                        }
                        return true
                    }
                }
                return false
            }
        })

        btnClose?.setOnClickListener {
            floatingView.findViewById<View>(R.id.card_translation_result)?.visibility = View.GONE
        }

        windowManager.addView(floatingView, windowParams)
    }

    private fun captureAndTranslateScreen() {
        val captureManager = screenCaptureManager
        if (captureManager == null) {
            Toast.makeText(this, "خدمة التقاط الشاشة غير مهيأة", Toast.LENGTH_SHORT).show()
            return
        }

        val resultCard = floatingView.findViewById<View>(R.id.card_translation_result)
        val tvResult = floatingView.findViewById<TextView>(R.id.tv_translation_result)
        val progressBar = floatingView.findViewById<ProgressBar>(R.id.pb_loading)

        resultCard.visibility = View.VISIBLE
        progressBar.visibility = View.VISIBLE
        tvResult.text = "جاري مسح نصوص اللعبة..."

        serviceScope.launch {
            // التقاط إطار شاشة نظيف من Redmi Note 14
            val bitmap = withContext(Dispatchers.Default) {
                captureManager.captureScreenBitmap()
            }

            if (bitmap == null) {
                progressBar.visibility = View.GONE
                tvResult.text = "فشل التقاط صورة الشاشة. تأكد من تشغيل اللعبة."
                return@launch
            }

            // التعرف على النصوص اللاتينية والإنجليزية بواسطة ML Kit OCR
            val image = InputImage.fromBitmap(bitmap, 0)
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    val detectedText = visionText.text.trim()
                    if (detectedText.isNotEmpty()) {
                        tvResult.text = "جاري التعريب بذكاء Gemini..."
                        translateWithGeminiAI(detectedText)
                    } else {
                        progressBar.visibility = View.GONE
                        tvResult.text = "لم يتم رصد نصوص واضحة في هذا المشهد"
                    }
                }
                .addOnFailureListener { e ->
                    progressBar.visibility = View.GONE
                    tvResult.text = "خطأ في قراءة الشاشة: ${e.localizedMessage}"
                }
        }
    }

    private fun translateWithGeminiAI(textToTranslate: String) {
        val tvResult = floatingView.findViewById<TextView>(R.id.tv_translation_result)
        val progressBar = floatingView.findViewById<ProgressBar>(R.id.pb_loading)

        serviceScope.launch {
            val gamingPrompt = """
                أنت مترجم ألعاب محترف وعالمي مختص بألعاب العالم المفتوح والـ RPG (مثل Genshin Impact, Honkai Star Rail).
                المطلوب: ترجم النص التالي المستخرج من شاشة اللعبة إلى لغة عربية فصحى معاصرة وممتعة للاعبين.
                
                شروط الترجمة:
                1. تعريب سياقي ذكي وليس ترجمة حرفية جامدة.
                2. الحفاظ على أسماء الأدوات والعتاد والمصطلحات الشائعة (مثل Artifacts, ATK, DMG, Primogems).
                3. تقديم النص المترجم مباشرة بدون أي كلام إضافي أو مقدمات.
                
                النص المستخرج:
                """
                $textToTranslate
                """
            """.trimIndent()

            try {
                val response = withContext(Dispatchers.IO) {
                    generativeModel.generateContent(gamingPrompt)
                }
                progressBar.visibility = View.GONE
                tvResult.text = response.text ?: "لا توجد ترجمة متوفرة"
            } catch (e: Exception) {
                progressBar.visibility = View.GONE
                tvResult.text = "تعذر الاتصال بالذكاء الاصطناعي: ${e.message}"
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceJob.cancel()
        screenCaptureManager?.release()
        if (::floatingView.isInitialized) {
            windowManager.removeView(floatingView)
        }
    }
}