# Screen Translator AI - Redmi Note 14 Project
تطبيق مترجم الألعاب والشاشة بالذكاء الاصطناعي (معدل لهاتف Redmi Note 14 وواجهة Xiaomi HyperOS).

## طريقة البناء والتشغيل في Android Studio:
1. قم بفك ضغط هذا المجلد على جهاز الكمبيوتر الخاص بك.
2. افتح برنامج Android Studio (إصدار Iguana أو Hedgehog أو Jellyfish).
3. اضغط على: File > Open... ثم اختر هذا المجلد.
4. انتظر حتى يكتمل فحص ومزامنة Gradle (Gradle Sync).
5. في ملف `app/build.gradle.kts`، ضع مفتاح Gemini API الخاص بك:
   `buildConfigField("String", "GEMINI_API_KEY", "\"YOUR_KEY\"")`
6. قم بتوصيل هاتف Redmi Note 14 عبر كابل USB مع تفعيل "تصحيح أخطاء USB".
7. اضغط على زر التشغيل الأخضر (Run ▶) أو من القائمة: Build > Build APK(s).
8. مبروك! سيتم تثبيت التطبيق وتوليد ملف الـ APK بنجاح.